"""Glue-oriented transformation package."""

