"""Document ingestion pipeline components."""
