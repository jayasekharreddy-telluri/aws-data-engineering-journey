#!/usr/bin/env bash
set -euo pipefail

# Creates the two Lambda zip files used by the manual AWS setup flow.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
BUILD_DIR="${REPO_ROOT}/build"

mkdir -p "${BUILD_DIR}"
rm -f "${BUILD_DIR}/ingestion-lambda.zip" "${BUILD_DIR}/query-lambda.zip"

cd "${REPO_ROOT}"
zip -qr "${BUILD_DIR}/ingestion-lambda.zip" src/__init__.py src/common src/ingestion
zip -qr "${BUILD_DIR}/query-lambda.zip" src/__init__.py src/common src/query_api

echo "Created:"
echo "  ${BUILD_DIR}/ingestion-lambda.zip"
echo "  ${BUILD_DIR}/query-lambda.zip"
